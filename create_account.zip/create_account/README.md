# Role Create Account
Tạo tài khoản PostgreSQL an toàn trên cụm HA Patroni.